//
//  HandCodedViewController.swift
//
//  Copyright © 2019 Purgatory Design. Licensed under the MIT License.
//

import UIKit

public class HandCodedViewController: UIViewController
{
    private var peacockButton: UIButton!
    private var peacockLabel: UILabel!

    @objc private func togglePeacockVisible() {
        self.peacockLabel.isHidden.toggle()
    }

    private func constructViews() {
        self.view.backgroundColor = .white

        let peacockButton = UIButton(type: .system)
        peacockButton.setTitle("Peacock", for: .normal)
        peacockButton.addTarget(self, action: #selector(togglePeacockVisible), for: .touchUpInside)
        peacockButton.accessibilityIdentifier = "Peacock Button"
        self.view.addSubview(peacockButton)
        self.peacockButton = peacockButton

        let peacock = UILabel(frame: .zero)
        peacock.text = "🦚"
        peacock.font = .systemFont(ofSize: 96.0)
        peacock.accessibilityIdentifier = "Peacock Label"
        peacock.isHidden = true
        self.view.addSubview(peacock)
        self.peacockLabel = peacock
    }

    public override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationItem.title = "5"
        self.constructViews()
    }

    public override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()

        self.peacockButton.frame = CGRect(x: 30.0, y: 120.0, width: 0.0, height: 0.0)
        self.peacockButton.sizeToFit()
        self.peacockLabel.frame = CGRect(x: 140.0, y: 110.0, width: 0.0, height: 0.0)
        self.peacockLabel.sizeToFit()
    }
}
