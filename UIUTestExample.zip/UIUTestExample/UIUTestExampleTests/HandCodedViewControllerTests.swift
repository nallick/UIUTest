//
//  HandCodedViewControllerTests.swift
//
//  Copyright © 2019 Purgatory Design. Licensed under the MIT License.
//

import XCTest
import UIUTestExample

class HandCodedViewControllerTests: XCTestCase
{
    override func tearDown() {
        super.tearDown()
        UIViewController.flushPendingTestArtifacts()
    }

    func testPeacockButtonTogglesPeacockLabelVisibility() {
        let viewController = HandCodedViewController()
        viewController.loadForTesting()
        let peacockButton = viewController.view!.viewWithAccessibilityIdentifier("Peacock Button") as! UIButton
        let peacockLabel = viewController.view!.viewWithAccessibilityIdentifier("Peacock Label") as! UILabel

        XCTAssertTrue(peacockLabel.isHidden)
        peacockButton.simulateTouch()
        XCTAssertFalse(peacockLabel.isHidden)
    }
}
